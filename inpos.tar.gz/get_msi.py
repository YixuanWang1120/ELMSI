#!/usr/bin/env python
# -*- coding: utf-8 -*-

path="inpos4.txt"
f=open(path)
list=f.readlines()
dic=[]
for i in range(len(list)):
    #dic[i]=list[i].split('\t')
    dic=list[i].split('\t')
    #dic.append(int(dic[2])*int(dic[4]))
    list[i]=str(int(dic[2])*int(dic[4]))+'\t'+list[i]
f=open(r'inposlen.txt','w')
f.writelines(list)
f.close()


