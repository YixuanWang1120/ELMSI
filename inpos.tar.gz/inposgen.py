#!/usr/bin/env python
# -*- coding: utf-8 -*-

#output num startpos inlen intype insert_times vartion_number seq
#parameter unit_len repete_times
#option SNP_pos
import random

intype=1
insert_times=1
vartion_number=0    
MSI_NUM=20

def MSI_POS(MSI_NUM):
	result=[]
	for i in range(MSI_NUM):
		num=i+1
		startpos=random.choice(xrange(1,1000000))
		unit_len=random.choice(range(1,6))
		seq=unit=''
		for x in range(unit_len):
	  		 unit+=random.choice("ATCG")
		repete_times=random.choice(range(10,200))
		seq=unit*repete_times
		inlen=unit_len*repete_times
		
		#SNP_pos=random.choice(range(inlen))
		#seq=seq[:SNP_pos]+creatSNP(seq[SNP_pos])+seq[SNP_pos+1:len(seq)]
		SNP_pos=0

		result.append('\t'.join([str(num),str(startpos),str(inlen),str(intype),str(insert_times),str(vartion_number),seq,'\n']))
	return result



def creatSNP(base): 
    if base == 'A' or base == 'a' or base == 'T' or base == 't':
        return 'C'
   
    if base == 'C' or base == 'c' or base == 'G' or base == 'g':
        return 'A'


if __name__ == "__main__":
	result=MSI_POS(1)
	print result
